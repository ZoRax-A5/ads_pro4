#include <bits/stdc++.h>

using namespace std;

typedef struct HuffmanNode *node;
struct HuffmanNode{
	char data;
	int freq;
	node left;
	node right;
};
struct tmp{
	bool operator()(node n1, node n2){
		return n1->freq > n2->freq;
	}
};

ofstream ofs;

node New_Node(char data, int freq){
	node new_node = (node)malloc(sizeof(struct HuffmanNode));
	new_node->data = data;
	new_node->freq = freq;
	new_node->left = NULL;
	new_node->right = NULL;
	return new_node;
}

node Merge_Node(node node1, node node2){
	node new_node = (node)malloc(sizeof(struct HuffmanNode));
	new_node->data = 0;
	new_node->freq = node1->freq + node2->freq;
	if (rand() % 2 - 1){
		new_node->left = node1;
		new_node->right = node2;
	}
	else{
		new_node->left = node2;
		new_node->right = node1;
	}
	
}

int print(node n, string code){
	if (n->data == 0){
		print(n->left, code + "0");
		print(n->right, code + "1");
	}
	else{
		ofs << n->data << " " << code << endl;
	}
}

int main(){
	int n, m;
	cin >> n >> m;
	const char chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_";
	int freqs[63];
	ofs.open("test.in", ios::out);
	priority_queue<node, vector<node>, tmp> pq;
	srand(time(NULL));
	
	
	ofs << n << endl;
	for (int i = 0; i < n; i++){
		freqs[i] = rand();
		ofs << chars[i] << " " << freqs[i] << " ";
	}
	ofs << endl << m << endl;
	while (m--){
		for (int i = 0; i < n; i++){
			pq.push(New_Node(chars[i], freqs[i]));
		}
		while (pq.size() > 1){
			node n1 = pq.top();
			pq.pop();
			node n2 = pq.top();
			pq.pop();
			pq.push(Merge_Node(n1, n2));
		}
		node root = pq.top();
		pq.pop();
		print(root, "");
	}
	ofs.close();
	return 0;
}
