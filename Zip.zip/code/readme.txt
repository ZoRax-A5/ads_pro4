Just open the *.cpp and compile to run. Or if any error happens, just run the corresponding executive file.

The "Huffman_code.cpp" uses an ordinary array to test whether there are some characters being encoded in non-leaf nodes, while the "trie.cpp" uses a prefix tree to handle this problem, with a lower time cost but a relatively higher space cost.